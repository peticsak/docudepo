let slider = document.getElementById("fogySlider");
let output = document.getElementById("fogyFt");
let haviKw = document.getElementById("haviKw");
let expYearSav = document.getElementById("expYearSav");
let osszKtg = document.getElementById("osszKtg");
let onKtg = document.getElementById("onKtg");
let tamogatas = document.getElementById("tamogatas");
let megterules = document.getElementById("megterules");

slider.oninput = function () {
  let haviFogyFt = this.value;
  let haviFogyKw = Math.floor(this.value * 0.026625);
  let varEvFogy = this.value * 12;
  let eviFogyKw = Math.floor(this.value * 0.026625 * 12);
  let eviFogyFt = this.value * 12;
  let osszKtgVal = eviFogyFt * 6.9;
  let onKtgVal = osszKtgVal / 2;
  let tamogatasVal = onKtgVal;
  let megterulesVal = (onKtgVal / eviFogyFt) * 12;

  output.innerHTML = new Intl.NumberFormat("hu-HU", {
    style: "currency",
    currency: "HUF",
    maximumSignificantDigits: 6,
  }).format(haviFogyFt);
  haviKw.innerHTML = new Intl.NumberFormat("hu-HU").format(haviFogyKw);
  eviKw.innerHTML = new Intl.NumberFormat("hu-HU").format(eviFogyKw);
  evFogyFt.innerHTML = new Intl.NumberFormat("hu-HU", {
    style: "currency",
    currency: "HUF",
    maximumSignificantDigits: 6,
  }).format(eviFogyFt);
  expYearSav.innerHTML = new Intl.NumberFormat("hu-HU", {
    style: "currency",
    currency: "HUF",
    maximumSignificantDigits: 6,
  }).format(varEvFogy);
  osszKtg.innerHTML = new Intl.NumberFormat("hu-HU", {
    style: "currency",
    currency: "HUF",
    maximumSignificantDigits: 6,
  }).format(osszKtgVal);
  onKtg.innerHTML = new Intl.NumberFormat("hu-HU", {
    style: "currency",
    currency: "HUF",
    maximumSignificantDigits: 6,
  }).format(onKtgVal);
  tamogatas.innerHTML = new Intl.NumberFormat("hu-HU", {
    style: "currency",
    currency: "HUF",
    maximumSignificantDigits: 6,
  }).format(tamogatasVal);
  megterules.innerHTML = Math.floor(megterulesVal);
};

function addElement() {
  var itm = document.getElementById("row2");
  var cln = itm.cloneNode(true);
  document.getElementById("row1").appendChild(cln);
}
